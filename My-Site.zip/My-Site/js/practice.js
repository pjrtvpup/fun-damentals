// function compareNumbers(a,b) {
// 	if (a > b) {
// 		return "it's bigger!"
// 	} else {
// 		return "it's smaller!"
// 	}
// };

// if(a<10){
// 	console.log("a is less than 10.")
// } else {
// 	console.log("a is a and is greater than 10.")
// };


// function declareWord (wordInput) {
// 	return alert(wordInput) 
// };

// function typeHam() {
// };

// function openDoor (door) {
// 	if (door === 1) {
// 		return "Cupcake"
// 	} else if (door === 2) {
// 		return "Whiskey"
// 	} else if (door === 3) {
// 		return "New Car"
// 	};
// };


// var meMe = 500,
//  	meMo = "500";


// var friends = ["MK", "Kyle", "Sean", "Laura"]
// for(var i=0; i<friends.length; i--){
// 	console.log(friends[i] + " is pretty cool");
// };



// for(var i=99; i>0; i--){
// console.log (i + " bottles of root beer on the wall," +
// 		i + " bottles of beer.  You take one down, pass it around," +
// 		i-- + " bottles of beer on the wall.");
// };




for(var i = 99; i>0; i--){
	console.log(i + " bottles of beer");
};